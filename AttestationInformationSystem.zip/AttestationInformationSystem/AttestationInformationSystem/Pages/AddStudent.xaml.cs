﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AttestationInformationSystem.Entities;
namespace AttestationInformationSystem.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddStudent.xaml
    /// </summary>
    public partial class AddStudent : Page
    {
        Employees employee = new Employees();
        public AddStudent(Employees enteredEmployee)
        {
            InitializeComponent();
            
             employee = enteredEmployee;
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities.Entities db = Entities.Entities.GetContext();
                Student students = new Student();
                students.FirstName = NameBox.Text.Trim();
                students.LastName = LastNameBox.Text.Trim();
                students.Patronymic = PatronymicBox.Text.Trim();
                students.Email = EmailBox.Text.Trim();
                students.Telephone = TelephoneBox.Text.Trim();
                students.IdGroup = int.Parse( IdGroupBox.Text.Trim());
                students.IdSpeciality = int.Parse(IdSpecialityBox.Text.Trim());
                students.IdStatusStudent = int.Parse(IdStatusStudent.Text.Trim());
                db.Student.Add(students);
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                NavigationService.Navigate(new Students(employee));
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }
    }
}
